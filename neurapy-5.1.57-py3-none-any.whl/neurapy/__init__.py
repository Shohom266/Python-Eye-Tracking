"""NeuraPy package."""

__version__ = "v5.1.57"
